import assert from "node:assert";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  codexArgs,
  geminiStyleArgs,
  parseCodexLine,
  parseGeminiOutput,
  parseQwenOutput,
  runCodexHeadless,
  runGeminiStyleHeadless,
  type HeadlessEvent,
} from "../electron/headlessAdapters.ts";
import { gatewayEnvForCli } from "../electron/modelRegistry.ts";

let passed = 0;
function check(name: string, cond: boolean, extra?: string) {
  if (cond) {
    passed++;
    console.log(`ok ${passed} - ${name}`);
  } else {
    console.error(`FAIL - ${name}${extra ? ` :: ${extra}` : ""}`);
    process.exit(1);
  }
}

const claudeEnv = gatewayEnvForCli("claude", "http://10.0.0.2:8787", "tk-test");
check("claude 网关注入：ANTHROPIC_BASE_URL + token + 模型",
  claudeEnv?.ANTHROPIC_BASE_URL === "http://10.0.0.2:8787" &&
  claudeEnv.ANTHROPIC_AUTH_TOKEN === "tk-test" &&
  claudeEnv.ANTHROPIC_MODEL === "claude-sonnet-4-5", JSON.stringify(claudeEnv));

const codexEnv = gatewayEnvForCli("codex", "http://10.0.0.2:8787", "tk-test");
check("codex 网关注入：OPENAI_BASE_URL 带 /v1",
  codexEnv?.OPENAI_BASE_URL === "http://10.0.0.2:8787/v1" && codexEnv.OPENAI_API_KEY === "tk-test" &&
  codexEnv.OPENAI_MODEL === "gpt-5-codex", JSON.stringify(codexEnv));

const qwenEnv = gatewayEnvForCli("qwen", "http://10.0.0.2:8787", "tk-test");
check("qwen 网关注入：OpenAI 兼容 + qwen3-coder-plus",
  qwenEnv?.OPENAI_MODEL === "qwen3-coder-plus", JSON.stringify(qwenEnv));

check("kimi/gemini 不注入", gatewayEnvForCli("kimi", "x", "k") === null && gatewayEnvForCli("gemini", "x", "k") === null);

const codexArgv = codexArgs("修复测试");
check("codex 参数：exec --json --skip-git-repo-check -s workspace-write + prompt",
  codexArgv.join(" ") === 'exec --json --skip-git-repo-check -s workspace-write 修复测试', codexArgv.join(" "));

const geminiArgv = geminiStyleArgs("gemini", "你好");
check("gemini 参数：-p + --output-format json + --yolo",
  geminiArgv.join(" ") === '-p 你好 --output-format json --yolo', geminiArgv.join(" "));

const qwenArgv = geminiStyleArgs("qwen", "你好");
check("qwen 参数：位置 prompt（-p 已废弃）+ --output-format json + --yolo",
  qwenArgv.join(" ") === '你好 --output-format json --yolo', qwenArgv.join(" "));

const ev1 = parseCodexLine('{"type":"item.completed","item":{"id":"i3","type":"agent_message","text":"回复文本"}}');
check("codex agent_message → assistant", ev1?.type === "assistant" && ev1.text === "回复文本");

const ev2 = parseCodexLine('{"type":"item.completed","item":{"id":"i2","type":"reasoning","text":"思考一下"}}');
check("codex reasoning → thought", ev2?.type === "thought" && ev2.text === "思考一下");

const ev3 = parseCodexLine('{"type":"item.started","item":{"id":"i1","type":"command_execution","command":"bash -lc ls","status":"in_progress"}}');
check("codex command_execution → tool", ev3?.type === "tool" && ev3.text === "bash -lc ls");

const ev4 = parseCodexLine('{"type":"item.completed","item":{"id":"i4","type":"file_change","changes":[{"path":"src/a.ts"}]}}');
check("codex file_change → tool 带路径", ev4?.type === "tool" && (ev4.text ?? "").includes("src/a.ts"));

const ev5 = parseCodexLine('{"type":"thread.started","thread_id":"t1"}');
check("codex thread.started 忽略", ev5 === null);

const ev6 = parseCodexLine('{"type":"turn.completed","usage":{"input_tokens":1}}');
check("codex turn.completed 忽略", ev6 === null);

const ev7 = parseCodexLine('{"type":"turn.failed","message":"boom"}');
check("codex turn.failed → error", ev7?.type === "error" && ev7.text === "boom");

const ev8 = parseCodexLine('{"type":"item.completed","item":{"id":"i9","item_type":"assistant_message","text":"旧版字段"}}');
check("codex 旧版 item_type/assistant_message 兼容", ev8?.type === "assistant" && ev8.text === "旧版字段");

const ev9 = parseCodexLine("这不是 JSON");
check("codex 非 JSON 行 → unparsed", ev9?.type === "unparsed");

const ev10 = parseCodexLine('{"type":"error","message":"Reconnecting... 2/5 (stream disconnected)"}');
check("codex 瞬时 Reconnecting 错误降级为 stderr", ev10?.type === "stderr");

const ev11 = parseCodexLine('{"type":"item.completed","item":{"id":"i0","type":"error","message":"Falling back from WebSockets"}}');
check("codex item.type=error → error 事件", ev11?.type === "error" && ev11.text === "Falling back from WebSockets");

const g1 = parseGeminiOutput('{"response":"gemini 回复","stats":{}}');
check("gemini JSON → response", g1.response === "gemini 回复" && !g1.error);

const g2 = parseGeminiOutput('{"error":{"message":"quota exceeded"}}');
check("gemini error 对象 → error", g2.error === "quota exceeded");

const g3 = parseGeminiOutput("纯文本输出");
check("gemini 非 JSON 兜底为文本", g3.response === "纯文本输出");

const g4 = parseGeminiOutput("   ");
check("gemini 空输出 → error", !!g4.error);

const q1 = parseQwenOutput('[{"type":"result","subtype":"success","is_error":false,"result":"qwen 最终回复"}]');
check("qwen result 数组 → response", q1.response === "qwen 最终回复" && !q1.error);

const q2 = parseQwenOutput('[{"type":"result","subtype":"error_during_execution","is_error":true,"error":{"message":"No auth type is selected."}}]');
check("qwen result error → error", q2.error === "No auth type is selected.");

const q3 = parseQwenOutput('[{"type":"assistant","message":{"content":[{"type":"text","text":"中间回复"}]}},{"type":"result","is_error":false,"result":"  "}]');
check("qwen result 为空 → 回退 assistant 文本", q3.response === "中间回复");

const dir = fs.mkdtempSync(path.join(os.tmpdir(), "teamai-mock-cli-"));

function writeMock(name: string, body: string): string {
  const p = path.join(dir, name);
  fs.writeFileSync(p, `#!/usr/bin/env node\n${body}`);
  fs.chmodSync(p, 0o755);
  return p;
}

const mockCodex = writeMock("fake-codex.mjs", `
const lines = [
  { type: "thread.started", thread_id: "t1" },
  { type: "turn.started" },
  { type: "item.started", item: { id: "i1", type: "command_execution", command: "bash -lc ls", status: "in_progress" } },
  { type: "item.completed", item: { id: "i1", type: "command_execution", command: "bash -lc ls", status: "completed" } },
  { type: "item.completed", item: { id: "i2", type: "reasoning", text: "想一下" } },
  { type: "item.completed", item: { id: "i3", type: "agent_message", text: "codex 最终回复" } },
  { type: "turn.completed", usage: { input_tokens: 10, output_tokens: 5 } },
];
for (const l of lines) console.log(JSON.stringify(l));
console.error("progress info on stderr");
`);

const mockCodexFail = writeMock("fake-codex-fail.mjs", `
console.error("auth failed: invalid api key");
process.exit(1);
`);

const mockGemini = writeMock("fake-gemini.mjs", `
console.log(JSON.stringify({ response: "gemini 最终回复", stats: { models: {} } }));
console.error("some warning");
`);

const mockGeminiFail = writeMock("fake-gemini-fail.mjs", `
console.error("boom on stderr");
process.exit(1);
`);

const mockGeminiStderrJson = writeMock("fake-gemini-stderr-json.mjs", `
console.error("YOLO mode is enabled. All tool calls will be automatically approved.");
console.error(JSON.stringify({ session_id: "s1", error: { type: "Error", message: "Please set an Auth method" } }, null, 2));
process.exit(41);
`);

const mockQwen = writeMock("fake-qwen.mjs", `
console.log(JSON.stringify([
  { type: "assistant", message: { content: [{ type: "text", text: "qwen 思考回复" }] } },
  { type: "result", subtype: "success", is_error: false, result: "qwen 最终回复" },
]));
console.error("Warning: yolo notice");
`);

function collect(run: (onEvent: (ev: HeadlessEvent) => void) => void): Promise<HeadlessEvent[]> {
  return new Promise((resolve) => {
    const events: HeadlessEvent[] = [];
    run((ev) => {
      events.push(ev);
      if (ev.type === "exit") setTimeout(() => resolve(events), 30);
    });
  });
}

const cwd = fs.mkdtempSync(path.join(os.tmpdir(), "teamai-mock-cwd-"));

const codexEvents = await collect((cb) => runCodexHeadless({ prompt: "干活", cwd, command: mockCodex }, cb));
check("mock codex：收到 assistant 回复",
  codexEvents.some((e) => e.type === "assistant" && e.text === "codex 最终回复"), JSON.stringify(codexEvents));
check("mock codex：收到 thought 与 tool",
  codexEvents.some((e) => e.type === "thought") && codexEvents.some((e) => e.type === "tool" && (e.text ?? "").includes("ls")));
check("mock codex：stderr 进度不产生 error 事件", !codexEvents.some((e) => e.type === "error"));
check("mock codex：exit 0 结束", codexEvents.some((e) => e.type === "exit" && e.text === "0"));

const codexFailEvents = await collect((cb) => runCodexHeadless({ prompt: "干活", cwd, command: mockCodexFail }, cb));
check("mock codex 失败：error 含 stderr 内容",
  codexFailEvents.some((e) => e.type === "error" && (e.text ?? "").includes("auth failed")), JSON.stringify(codexFailEvents));
check("mock codex 失败：exit 1", codexFailEvents.some((e) => e.type === "exit" && e.text === "1"));

const geminiEvents = await collect((cb) => runGeminiStyleHeadless("gemini", { prompt: "干活", cwd, command: mockGemini }, cb));
check("mock gemini：收到 assistant 回复",
  geminiEvents.some((e) => e.type === "assistant" && e.text === "gemini 最终回复"), JSON.stringify(geminiEvents));
check("mock gemini：warning 不产生 error 事件", !geminiEvents.some((e) => e.type === "error"));

const geminiFailEvents = await collect((cb) => runGeminiStyleHeadless("qwen", { prompt: "干活", cwd, command: mockGeminiFail }, cb));
check("mock qwen 失败：error 含 stderr 内容",
  geminiFailEvents.some((e) => e.type === "error" && (e.text ?? "").includes("boom")), JSON.stringify(geminiFailEvents));

const geminiStderrEvents = await collect((cb) => runGeminiStyleHeadless("gemini", { prompt: "干活", cwd, command: mockGeminiStderrJson }, cb));
check("mock gemini：stderr JSON 错误提取 message",
  geminiStderrEvents.some((e) => e.type === "error" && e.text === "Please set an Auth method"), JSON.stringify(geminiStderrEvents));

const qwenEvents = await collect((cb) => runGeminiStyleHeadless("qwen", { prompt: "干活", cwd, command: mockQwen }, cb));
check("mock qwen：收到 assistant 回复（result 字段）",
  qwenEvents.some((e) => e.type === "assistant" && e.text === "qwen 最终回复"), JSON.stringify(qwenEvents));
check("mock qwen：yolo warning 不产生 error 事件", !qwenEvents.some((e) => e.type === "error"));

const missingCmdEvents = await collect((cb) =>
  runCodexHeadless({ prompt: "干活", cwd, command: "definitely-not-exist-cli-xyz" }, cb));
check("命令不存在：error 启动失败", missingCmdEvents.some((e) => e.type === "error" && (e.text ?? "").includes("启动失败")));

console.log(`\nALL ${passed} ADAPTER TESTS PASSED`);
process.exit(0);

void fileURLToPath;
