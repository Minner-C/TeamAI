import { ipcMain, dialog } from "electron";
import { detectClis, installCli } from "./headlessManager.js";
import { listModelRoutes } from "./modelRegistry.js";
import { cloneRepo, pushWorkspace } from "./gitWorkspace.js";
import { ideListDir, ideReadFile, ideWriteFile } from "./ideWorkspace.js";
import { ImClient } from "./imClient.js";
import { respondAgentPermission, runAgentCli, stopAgentCli } from "./agentRunner.js";
import {
  checkServerHealth,
  chatStream,
  createRepo,
  deleteRepo,
  getConnection,
  gitRemoteUrl,
  listModels,
  listRepos,
  login,
  repoCommits,
  saveSession,
  setConnection,
  setTokens,
  usageSummary,
  type ChatMessage,
} from "./serverClient.js";

export function registerIpcHandlers() {
  let latestImClient: ImClient | null = null;
  ipcMain.handle("cli:detect", () => detectClis());
  ipcMain.handle("cli:install", (_e, kind: string) => installCli(kind));
  ipcMain.handle("models:routes", () => listModelRoutes());
  ipcMain.handle("server:health", () => checkServerHealth());
  ipcMain.handle("server:setUrl", (_e, url: string) => {
    setConnection(url, null);
    return true;
  });
  ipcMain.handle("connection:setTokens", (_e, token: string, refreshToken?: string) => {
    setTokens(token, refreshToken);
    return true;
  });
  ipcMain.handle("auth:login", (_e, email: string, password: string) => login(email, password));
  ipcMain.handle("models:list", () => listModels());
  ipcMain.handle("usage:summary", () => usageSummary());

  ipcMain.handle("repos:list", () => listRepos());
  ipcMain.handle("repos:create", (_e, name: string, group: string) => createRepo(name, group));
  ipcMain.handle("repos:delete", (_e, id: string) => deleteRepo(id));
  ipcMain.handle("repos:commits", (_e, id: string) => repoCommits(id));
  ipcMain.handle("repos:remoteUrl", (_e, group: string, name: string, email: string) =>
    gitRemoteUrl(group, name, email),
  );
  ipcMain.handle("dialog:pickDir", async () => {
    const r = await dialog.showOpenDialog({ properties: ["openDirectory", "createDirectory"] });
    return r.canceled ? null : r.filePaths[0];
  });
  ipcMain.handle("ide:listDir", (_e, root: string, rel: string) => ideListDir(root, rel ?? ""));
  ipcMain.handle("ide:readFile", (_e, root: string, rel: string) => ideReadFile(root, rel));
  ipcMain.handle("ide:writeFile", (_e, root: string, rel: string, content: string) =>
    ideWriteFile(root, rel, content),
  );
  ipcMain.handle("git:clone", (_e, repoUrl: string, targetDir: string) =>
    cloneRepo(repoUrl, targetDir),
  );
  ipcMain.handle(
    "git:pushWorkspace",
    async (
      _e,
      input: { cwd: string; group: string; name: string; message: string; authorName: string; authorEmail: string },
    ) => {
      const repos = await listRepos().catch(() => []);
      if (!repos.some((r) => r.group === input.group && r.name === input.name)) {
        await createRepo(input.name, input.group);
      }
      const remoteUrl = gitRemoteUrl(input.group, input.name, input.authorEmail);
      const result = await pushWorkspace(input.cwd, remoteUrl, input.message, {
        name: input.authorName,
        email: input.authorEmail,
      });
      return { ...result, repo: `${input.group}/${input.name}` };
    },
  );
  ipcMain.handle(
    "sessions:save",
    (_e, input: { title?: string; cli?: string; taskId?: string; messages: unknown[] }) =>
      saveSession(input),
  );

  ipcMain.handle("im:connect", (event) => {
    const conn = getConnection();
    const client = new ImClient();
    latestImClient = client;
    client.connect(conn.baseUrl, conn.token ?? "", (ev) => {
      if (!event.sender.isDestroyed()) event.sender.send("im:event", ev);
    });
    event.sender.once("destroyed", () => {
      client.disconnect();
      if (latestImClient === client) latestImClient = null;
    });
    return true;
  });

  ipcMain.handle("im:typing", (_e, channelId: string) => {
    latestImClient?.send({ type: "typing", channelId });
    return true;
  });

  ipcMain.handle(
    "agent:run",
    async (event, input: { taskId: string; cli: string; cwd: string; prompt: string; viaGateway?: boolean }) => {
      await runAgentCli(input.taskId, input.cli, input.cwd, input.prompt, (ev) => {
        if (!event.sender.isDestroyed()) event.sender.send("agent:event", ev);
      }, { viaGateway: input.viaGateway });
      return true;
    },
  );
  ipcMain.handle("agent:stop", (_e, taskId: string) => stopAgentCli(taskId).then(() => true));
  ipcMain.handle(
    "agent:permission",
    (_e, input: { taskId: string; requestId: string; allow: boolean }) => {
      respondAgentPermission(input.taskId, input.requestId, input.allow);
      return true;
    },
  );

  ipcMain.handle(
    "chat:send",
    async (event, req: { requestId: string; model: string; messages: ChatMessage[] }) => {
      try {
        await chatStream(req.model, req.messages, (delta) => {
          event.sender.send("chat:chunk", { requestId: req.requestId, delta });
        });
        event.sender.send("chat:chunk", { requestId: req.requestId, done: true });
      } catch (err) {
        event.sender.send("chat:chunk", {
          requestId: req.requestId,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    },
  );
}
